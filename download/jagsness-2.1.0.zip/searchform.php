<form action="/" class="" method="get">
    <h5 class="alert alert-info text-center">Search Form</h5>
    <input type="text" value="<?php the_search_query(); ?>" class="form-control mb-4 ap-input" name="s" required>
    <button type='submit' class="w-100 btn btn-success ap-button">SEARCH</button>
</form>                
